<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<section class="vh-100" style="background-color: #B0E0E6;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card shadow-2-strong" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">
            
            <form action="<?= base_url('/login')?>" method="POST">
              <h1 class="h3 mb-3 fw-normal">CRUD Login</h1>
              <?php if(session()->getFlashdata('pesan')):?>
            <div class="alert alert-warning" role="alert">
            <?= session()->getFlashdata('pesan')?>
                </div>
                <?php endif ?>
           <div class="form-floating">
                <input type="text" class="form-control" id="floatingInput" placeholder="username" name="username">
                <label for="floatingInput">Username</label>
              </div>
              <div class="form-floating">
                <input type="email" class="form-control" id="floatingInut" placeholder="name@example.com" name="email">
                <label for="floatingInput">Email address</label>
              </div>
              <div class="form-floating">
                <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password">
                <label for="floatingPassword">Password</label>
              </div>
          
              <button class="w-100 mt-2 btn btn-lg btn-primary" type="submit">Sign in</button>
              
            </form>
          </main>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>          
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>